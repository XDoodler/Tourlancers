<?php 
      class customException extends Exception {
        public function errorMessage() {
          //error message
          $errorMsg ='Page is not found';
          return $errorMsg;
        }
      }
      
     require_once('db.php');
    if(isset($_GET['FILTERED_LOCATION']))
    {
      $city=filter_var($_GET['FILTERED_LOCATION'], FILTER_SANITIZE_STRING,FILTER_FLAG_STRIP_HIGH);
      $dest=filter_var($_GET['FILTERED_DESTINATION'], FILTER_SANITIZE_STRING,FILTER_FLAG_STRIP_HIGH);
    }
    else 
    {
      
      throw new customException();
        
     
    }
    $status="popular";

    function show_ratings($x)
    {
      if($x==0)
       {
         $rating="Unrated";
       }
       elseif($x>0.0 && $x<=1.0)
       {
         $rating="Below Average";
       }
       elseif($x>1.0 && $x<=2.0)
       {
         $rating=" Average";
       }
       elseif($x>2.0 && $x<=3.0)
       {
         $rating="Above Average";
       }
       elseif($x>3.0 && $x<=3.9)
       {
         $rating="Good";
       }
       elseif($x>3.9 && $x<=4.4)
       {
         $rating="Very Good";
       }
       elseif($x>4.4 && $x<=5.0)
       {
         $rating="Excellent";
       }
       return $rating;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/css?family=Cabin" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <title>City</title>
    <style>
        
    </style>
</head>
<body style="background: 
radial-gradient(circle at 100% 50%, transparent 260%, rgba(231,134,143,.3) 21%, rgba(255,255,255,.3) 34%, transparent 35%, transparent),
radial-gradient(circle at 50% 50%, transparent 20%, rgba(255,255,255,.3) 21%, rgba(255,255,255,.3) 34%, transparent 35%, transparent) 0 -50px;
background-color: rgb(244, 215, 237);
background-size:75px 100px;">
<!--navbar start-->
<div class="navbar-fixed">
   <nav class="red darken-2">
      <div class="container">
        <div class="nav-wrapper">
            <a href="#" class="brand-logo logo">Tourlancers</a>
            <a href="" data-target="mobile-nav" class="sidenav-trigger"><i class="material-icons">menu</i></a>
               <ul class="right hide-on-med-and-down">
                  <li>
                      <a href="https://tourlancers.com"><i class="fas fa-home"></i> <span class="white-text">Home </span></a>
                  </li>
                 
                   <li>
                      <a href="#"><i class="fas fa-male"></i> <span class="white-text">Travel Operator </span></a>
                              
                </ul>
            </div>
         </div>
     </nav>
 </div>
 <ul class="sidenav red darken-2" id="mobile-nav">
     <h4 class="center"> <i class="material-icons">map</i> 
           <?php  
            
             echo ucfirst($city);
             
             ?>
     </h4>
    
    <li>
         <a href="#op"><i class="fas fa-male white-text"></i> <span class="white-text">Travel Operator </span></a>
    </li>
      
 </ul>
 <!--navbar-end-->  
 <!--header-->
  <section class="center">
     <img src="TL4.png"  alt="" class="responsive-img">
     </section>
 <!--header-End-->
 <!--Search bar-->
 <form style="margin :-10px ;" action="filter.php" method="GET">
    <div id="search" class="  white-text center scrollspy" style="background: linear-gradient(to right,  #ffa64d
 , #ff0055);">
        <div style="padding:5px;" class="container">
            <div class="row">
                <div class="col s12 m6">
                   <label for="" class="white-text">FILTER BY YOUR LOCATION </label>
                  <select style="margin:10px; padding:10px;" class="browser-default white accent-3 red-text" name="FILTERED_LOCATION">
                    <option value="" disabled selected>WHERE ARE YOU TRAVELING FROM ?</option>
                    <option value="kolkata">KOLKATA</option>
                    <option value="puri">PURI</option>
                    <option value="chennai">CHENNAI</option>
                    <option value="delhi">DELHI</option>
                    <option value="hyderabad">HYDERABAD</option>
                    <option value="mumbai">MUMBAI</option>
                  </select>
                </div>
                <div class="col s12 m6">
                <label for="" class="white-text">FILTER BY YOUR DESTINATION</label>
                  <select style="margin:10px; padding:10px" class="browser-default white accent-3 red-text" name="FILTERED_DESTINATION">
                    <option value="" disabled selected>TO WHERE ARE YOU TRAVELLING ?</option>
                    <option value="kolkata">KOLKATA</option>
                    <option value="puri">PURI</option>
                    <option value="chennai">CHENNAI</option>
                    <option value="delhi">DELHI</option>
                    <option value="hyderabad">HYDERABAD</option>
                    <option value="mumbai">MUMBAI</option>

                  </select>
                </div>
            </div>
            <div>
                <input class="btn green" type="submit"value="SEARCH" name="filter">
            </div>
        </div>
      </div>
   </form>   
    
 <!--Search bar end-->
 
 <br>
   <div class="container">
        <h4 class="hide-on-small-only">Tour packages for 
        <?php  
            
             echo ucfirst($city);
              
          ?>
        </span></h4>
       <!--Popular Operators-->
        <?php 
           function operator($x) {
              if($x=="tour_operator"){
                  $result="PACKAGES";
                }
              else if($x=="car_rental"){
                $result="CAR RENTALS";
              }
              else{
                $result="TOUR GUIDES";
              }
               return $result;
           }
         ?>
         <?php 
             //echo " <h6 class='center green accent-3 card-panel'><b><i class='fas fa-male'> </i>".operator($_GET['FILTERED_TOUR'])."</b></h6>";
         ?>

       <!--Popular operators end-->
       <div class="row">
            <?php 
                if( isset($city) && isset($dest))
                {
                    
                  $sql="SELECT * FROM tour_packages WHERE package_city=? AND destination= ?";
                  $stmt=$pdo->prepare($sql);
                  $stmt->execute([$city,$dest]);
                  $operators = $stmt->fetchAll();
                   if($operators)
                   {
                     foreach($operators as $operator) 
                      {
                           
                    
                ?>
            <div class="col s12 m4">
              <div class="card " >
                 <div class="card-image">
                   <!--<img width="100" height="100" src="operators-img/galaxy.png"> -->
                     
                 </div>
                 <div class="card-content  indigo ">
                       <h4 class="white-text "><?php echo $operator->package_name; ?></h4>
                      
                      <h5 ><span class="white-text ">&#x20b9;<?php echo $operator->package_fee; ?></span></h5>
                 </div>
                 <div class="card-action">
                   <a href="https://tourlancers.com/beta/business/Operators/Operator_company_page_build/package.php?id=<?php echo $operator->id;?>&package_id=<?php echo $operator->package_id; ?>" class="red-text"><strong>View package</a>
                 </div></strong>
              </div> 
            </div>
            
            <?php 
                   }
                  
                  }
                   else { echo "<h5 class='center'><i class='material-icons orange-text large center'>sentiment_very_dissatisfied</i></h5><h5 class='center'>No operator is available</h5><br> ";}
                  }
                  
             ?>


             <?php 
                if(isset($city) && isset($dist))
                {
                  $sql="SELECT * FROM car_rentals WHERE city=?";
                  $stmt=$pdo->prepare($sql);
                  $stmt->execute([$city]);
                  $crs = $stmt->fetchAll();
                   if($crs)
                   {
                     foreach($crs as $cr)
                      {

                    
                ?>
            <div class="col s12 m4">
              <div class="card">
                 <div class="card-image">
                   <img width="100" height="200" src="operators-img/twin.jpeg">
                     
                 </div>
                 <div class="card-content deep-purple lighten-4" style="height: 300px">
                      <h4><?php echo $cr->name; ?></h4>
                      <h6 class="red-text"> <?php echo $cr->city; ?> </h6>
                      <p><?php echo $cr->location; ?></p>
                      <p><span class="indigo white-text"> <?php echo $cr->description; ?> </span> <span class="green-text grey lighten-3"></span></p>
                 </div>
                 <div class="card-action">
                   <a href="../business/Car_Rentals/carrentals_company_page_build/user.php?id=<?php echo $cr->id ?>" class="red-text">View</a>
                 </div>
              </div> 
            </div>
            
            <?php 
                   }
                  
                  } 

                   else { echo "<h5 class='center'><i class='material-icons orange-text large center'>sentiment_very_dissatisfied</i></h5><h5 class='center'>No operator is available</h5><br> ";}
                  }
                  else 
                 
             ?>
             
        </div>    
       <!--Popular Car Rentals-->
    
      
          
       <!--Popular Car Rentals end-->
        <!--Popular Hotels-->
            
       <!--Popular Hotels end-->
   </div>
          <!--Social Media follow-->
         


      <!--footer End-->
      <!--footer-->
    
           
   
 <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/js/materialize.min.js"></script>
 <script>
     const sideNav=document.querySelector('.sidenav');
     M.Sidenav.init(sideNav,{});
      document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.fixed-action-btn');
    var instances = M.FloatingActionButton.init(elems, {
      toolbarEnabled: true
    });
  });

</script>
</body>
</html>

 
              