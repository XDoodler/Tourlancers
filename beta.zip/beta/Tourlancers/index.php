<!DOCTYPE html>
<html>
  <head>
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/css?family=Cabin" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  </head>
      <title>Tourlancers</title>
  <body>
    <!--Nav bar start-->
    <div class="navbar-fixed">
        
        <nav class="teal">
            <div class="container">
                <div class="nav-wrapper">
                    <a href="#" class="brand-logo logo">Tourlancers.com</a>
                    <a href="" data-target="mobile-nav" class="sidenav-trigger">
                        <i class="material-icons">menu</i>
                    </a>
                    <ul class="right hide-on-med-and-down">
                        <li>
                            <a href="index.php"><i class="fa fa-home"></i><span class="white-text"> Home </span></a>
                        </li>
                         <li>
                            <a class='dropdown-trigger1' href='#' data-target='dropdown1'><i class="fa fa-shopping-cart"></i> <span class="white-text"> Deals </span> <i class="material-icons right">arrow_drop_down</i></a>
                
                           
                            <ul id='dropdown1' class='dropdown-content'>
                              <li><a href="#!"><i class="fa fa-plane"></i> Flight</a></li>
                              <li class="divider" tabindex="-1"></li>
                              <li><a href="#!"><i class="fa fa-store"></i> Rooms </a></li>
                              <li class="divider" tabindex="-1"></li>
                              <li><a href="#!"><i class="fa fa-building"></i> Hotels </a></li>
                              <li class="divider" tabindex="-1"></li>
                              <li><a href="#!"><i class="fa fa-utensils"></i> Restourant </a></li>
                              <li class="divider" tabindex="-1"></li> 
                          </ul> 
                        </li>
                        
                         <li>
                             <a href="#Galary"><i class="fab fa-envira"></i> <span class="white-text"> Gallary </span></a>
                        </li>
                        
                        <li>
                            <a href="contact/index.php"><i class="fa fa-envelope"></i> <span class="white-text"> Contact </span></a>
                        </li>
                         <li>
                            <a class='dropdown-trigger2' href='#' data-target='dropdown2'><i class="fa fa-user"></i> <span class="white-text">Sign-up</span><i class="material-icons right">arrow_drop_down</i> </a>
                            <ul id='dropdown2' class='dropdown-content'>
                                <li><a href="signin-signup/sign-up.php"> Sign-up </a></li>
                                <li class="divider" tabindex="-1"></li>
                                <li><a href="signin-signup/sign-in.php"> Sign-in </a></li>
                              </ul>  
                         </li>
                                
                                
                    </ul>
                </div>
            </div>
        </nav>
    </div>
    <ul class="sidenav teal lighten-2" id="mobile-nav">
        <li>
            <a href="index.php"><i class="fa fa-home"></i><span class="white-text"> Home </span></a>
        </li>
        <li>
            <a class='dropdown-trigger3' href='#' data-target='dropdown3'><i class="fa fa-shopping-cart"></i> <span class="white-text"> Deals</span><i class="material-icons right">arrow_drop_down</i></a>

            <!-- Dropdown Structure -->
            <ul id='dropdown3' class='dropdown-content'>
              <li><a href="#!"><i class="fa fa-plane"></i>Flight</a></li>
              <li class="divider" tabindex="-1"></li>
              <li><a href="#!"><i class="fa fa-store"></i>Rooms</a></li>
              <li class="divider" tabindex="-1"></li>
              <li><a href="#!"><i class="fa fa-building"></i>Hotels</a></li>
              <li class="divider" tabindex="-1"></li>
              <li><a href="#!"><i class="fa fa-utensils"></i>Restourant</a></li>
              <li class="divider" tabindex="-1"></li>
              
              
            </ul>
        </li>
        
         <li>
             <a href="#Galary"><i class="fab fa-envira"></i> <span class="white-text"> Gallary </span></a>
        </li>
        
        <li>
                <a href="contact/index.php"><i class="fa fa-envelope"></i> <span class="white-text"> Contact </span></a>
        </li>
         <li>
            <a class='dropdown-trigger4' href='#' data-target='dropdown4'><i class="fa fa-user"></i> <span class="white-text">Sign-up</span><i class="material-icons right">arrow_drop_down</i> </a>
            <ul id='dropdown4' class='dropdown-content'>
                <li><a href="signin-signup/sign-up.php">Sign-up</a></li>
                <li class="divider" tabindex="-1"></li>
                <li><a href="signin-signup/sign-in.php">Sign-in</a></li>
            </ul> 
        </li>
                
                    
        </ul>
    <!--Nav bar End-->

    <!--Start of Sliders-->
    <section class="slider">
        
        <ul class="slides">
          <li>
            <img src="img/houses.jpg"> 
            <div class="caption center-align">
              <h3>Take your Dream Vacation!</h3>
              <h5 class="light grey-text text-lighten-3">World Tour is dream of everyone to see the world once in a life</h5>
            </div>
          </li>
          <li>
            <img src="img/building.jpg"> 
            <div class="caption left-align">
              <h3>Nature is peace</h3>
              <h5 class="light grey-text text-lighten-3">Here's our small slogan.</h5>
            </div>
          </li>
          <li>
            <img src="img/hills.jpg"> 
            <div class="caption right-align">
              <h3>We Work With All Budget</h3>
              <h5 class="light grey-text text-lighten-3">Here's our small slogan.</h5>
            </div>
          </li>
         
           <section id="search" class="section section-search teal darken-1 white-text center scrollspy">

           </section>
        </ul>
   </section>     
 
    <!--End of Sliders-->
    <!--Search Area-->
    <nav>
        <div class="nav-wrapper teal">
          <div class="container">
            <ul id="nav-mobile" class="right">
                <li><a href=""><i class="fa fa-map-marker-alt"></i></a></li>
                <li><input type="text" placeholder="    Cities" class=" white"></li>
                <li><a class='dropdown-trigger5' href='' data-target='dropdown5'>Guide <i class="material-icons right">arrow_drop_down</i></a>

                    <!-- Dropdown Structure -->
                    <ul id='dropdown5' class='dropdown-content'>
                      <li><a href="#!">one</a></li>
                      <li class="divider" tabindex="-1"></li>
                      <li><a href="#!">two</a></li>
                      <li class="divider" tabindex="-1"></li>
                      <li><a href="#!">three</a></li>
                      <li class="divider" tabindex="-1"></li>
                    </ul>
                </li>
                <li><a href="collapsible.html"><i class="material-icons med">search</i></a></li>
              </ul>
          </div>
        </div>
      </nav>
    <!--Search Area End-->
    <!--Section icon boxes-->
    <section class="section section-icons  blue-grey lighten-4 center">
            <div class="container">
                <div class="row">
                    <h4 class="center"><span class="teal-text">Our</span> Deals</h4>
                    <a href="#">
                    <div class="col s12 m4">
                        <div class="card-panel"><i class="material-icons large teal-text">room</i>
                        <h4><a style="color:black;"  href="">Pick Room </a></h4>
                        <p> “Good location, it realy close to the pistes. Breakfast is little poor,
                             but by the way it is pretty well
                       </p>
                        </div>
                    </div>
                    </a>
                    <a href="#">
                    <div class="col s12 m4">
                        <div class="card-panel"><i class="material-icons large teal-text">store</i>
                            <h4><a style="color:black;" href="">Travel Shop </a></h4>
                            <p>Travel Shop Holidays provides you the best offers for various holiday packages in India</p>
                        </div>
                    </div>
                    </a>
                  <a href="#">  
                      <div class="col s12 m4">
                         <div class="card-panel"><i class="material-icons large teal-text">airplanemode_active</i>
                            <h4><a style="color:black;" href="">Fly Cheap </a></h4>
                            <p>Find cheap flights and save money on airline tickets to every destination in the world </p>
                         </div>
                    </div> 
                 </a>    
                </div>
            </div>
        </section>
        <!--icon boxes end -->
         <!--popular places Start-->
     <section id="popular" class="section grey darken-4 section-popular scrollspy">
            <div class="container">
                <div class="row">
                      <h4 class="center"><span class="teal-text">Popular Places</span></h4>
                    <div class="col s12 m4">
                        <div class="card">
                            <div class="card-image">
                                <img src="img/hill-station-1576868_640.jpg" alt="london">
                                <span class="card-title">Hill Station</span>
                                
                            </div>
                            <div class="card-content">
                               <b>Come and enjoy the beautiful day of Hill Station </b>
                            </div>
                        </div>
                    </div>
                    <div class="col s12 m4">
                      <div class="card">
                          <div class="card-image">
                              <img  src="img/shimla-555897_640.jpg" alt="Shimla">
                              <span style="color:bisque" class="card-title">Shimla</span>
                          </div>
                          <div class="card-content">
                             <b>Let's have a fun on the snow layers of Shimla </b>
                          </div>
                      </div>
                  </div>
                  <div class="col s12 m4">
                      <div class="card">
                          <div class="card-image">
                              <img src="img/bedroom-1285156_640.jpg" alt="gantok">
                              <span class="card-title">Beautiful Bedroom</span>
                          </div>
                          <div class="card-content">
                            <b> A beautiful day starts with a beautiful morning ,Thiland </b>
                          </div>
                      </div>
                  </div>
                </div>
                <div class="row">
                        
                      <div class="col s12 m4">
                          <div class="card">
                              <div class="card-image">
                                  <img src="img/houses.jpg" alt="london">
                                  <span class="card-title">Beautiful Evening</span>
                                  
                              </div>
                              <div class="card-content">
                                 <b>Come and enjoy the beautiful day of Hill Station </b>
                              </div>
                          </div>
                      </div>
                      <div class="col s12 m4">
                        <div class="card">
                            <div class="card-image">
                                <img  src="img/waterfall-1369319_640.jpg" alt="Shimla">
                                <span style="color:bisque" class="card-title">Gangtok,Waterfall</span>
                            </div>
                            <div class="card-content">
                               <b>Let's have a fun on the waterfall of Gangtok </b>
                            </div>
                        </div>
                    </div>
                    <div class="col s12 m4">
                        <div class="card">
                            <div class="card-image">
                                <img src="img/mountains-2915425_640.jpg" alt="gantok">
                                <span class="card-title">Dark Evening,Himalaya mountain</span>
                            </div>
                            <div class="card-content">
                              <b> A beautiful day starts with a beautiful dark evening ,Himalaya </b>
                            </div>
                        </div>
                    </div>
                  </div>
            </div>
            
       </section>
      <!--popular places end-->
      
      <!--Social Media follow-->
     <section class="section section-follow teal darken-2 white-text center">
            <div class="container">
                <div class="row">
                    <div class="col s12">
                        <h4>Follow Tourlancers</h4>
                        <p>Follow us on social media for special offers</p>
                        <a href="#" class="white-text">
                            <i class="fab fa-facebook fa-4x"></i>
                        </a>
                        <a href="#" class="white-text">
                              <i class="fab fa-github fa-4x"></i>
                        </a>
                          <a href="#" class="white-text">
                                  <i class="fab fa-linkedin fa-4x"></i>
                          </a>
                          <a href="#" class="white-text">
                                  <i class="fab fa-google-plus fa-4x"></i>
                          </a>
                          
                    </div>
                </div>
            </div> 
              
           </section>
            
          <!--Social Media follow End-->
          <!--footer-->
      <section class="section teal darken-2 white-text center">
            <div class="container">
                <div class="row">
                    <div class="col s12 m4">
                      <h5>Information</h5>
                      <p>About us | Our products | Press Release</p> 
                      <p>Costomer Testimonial | Partner with Us </p>
                     </div>  
                   <div class="col s12 m4">
                       <h5>Costomer Care</h5>
                       <p>Support & FAQ | Term & Condition | Privacy Policy</p> 
                       <p>User Agreement | Travel Agents</p> 
                   </div>
                    <div class="col s12 m4">
                       <h5>Partner Hotels</h5>
                       <p>Lorem, ipsum.</p>
                       <p>Lorem, ipsum.</p>
                       <p>Lorem, ipsum.</p>
                    </div>
                </div>
            </div>
        </section>
  
  
      <!--footer End-->
      <!--footer-->
     <footer class="section teal darken-2 white-text center">
            <p class="flow-text">Tourlancers &copy;2017-2018</p>
        </footer>
       <!--footer end-->
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/js/materialize.min.js"></script>
    <script>
     const sideNav=document.querySelector('.sidenav');
M.Sidenav.init(sideNav,{});
$('.dropdown-trigger1').dropdown();
$('.dropdown-trigger2').dropdown();
$('.dropdown-trigger3').dropdown();
$('.dropdown-trigger4').dropdown();
$('.dropdown-trigger5').dropdown();
//slider
const slider=document.querySelector('.slider');
M.Slider.init(slider,{
      indicators:false,
      height:400,
      transition:500,
      interval:3000});
const mb=document.querySelectorAll('.materialboxed');
M.Materialbox.init(mb,{});
    </script>       
  </body>
</html>