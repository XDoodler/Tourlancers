<?php function listify_custom_autolocation() {
	if ( ! ( is_front_page() || listify_is_job_manager_archive() ) ) {
		return;
	}

	if ( isset( $_GET['search_location'] ) ) {
		return;
	}
}
?>
	<script>
		jQuery(document).ready(function() {
			var locate = jQuery( '.locate-me' );
			locate.trigger( 'click' );
		});
	</script>
