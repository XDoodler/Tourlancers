<?php
require 'db.php';
    $data=$_POST;
    $paymentid=$data['payment_id'];
   
    $req=$data['payment_request_id'];

					$sql="UPDATE clients SET mojo='$paymentid', paid=1
                                               WHERE id='$req'";
				mysqli_query($mysqli, $sql);
			
				

?>