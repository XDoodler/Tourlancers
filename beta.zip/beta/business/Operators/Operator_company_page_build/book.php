 <?php
require 'db.php';
session_start();
// Check if user is logged in using the session variable
if ( !isset($_SESSION['logged_in'])) {
    //If the user is not logged in then check the url for unique email
    if((isset($_GET['id'])) && (isset($_GET['package_id']))) {
        $id = $_GET['id'];
        $package_id = $_GET['package_id'];
    } else {
        //If the user is not logged in and also the url doesn't contain unique email then we can't render the company page.
        $_SESSION['message'] = "Sorry, the company page doesn't exist!";
        header("location: ../../Business_Logins/error.php");
    }    
}
else if ( isset($_SESSION['logged_in'])) {
    //If the user is not logged in then check the url for unique email
    if((isset($_GET['id'])) && (isset($_GET['package_id']))) {
        $id = $_GET['id'];
        $package_id = $_GET['package_id'];
    } 
    else {
      $first_name = $_SESSION['first_name'];
    $last_name = $_SESSION['last_name'];
    $email = $_SESSION['email'];
    $active = $_SESSION['active'];
    $id=$_SESSION['id'];
    }
}
$pkg_id=$mysqli->query("SELECT * FROM tour_packages WHERE package_id = '$package_id'");
$t_id = $mysqli->query("SELECT * FROM tour_operators WHERE id = '$id'");
$pkg = $pkg_id->fetch_assoc();
$t = $t_id->fetch_assoc();
//$info=mysqli_query($mysqli,$sql);
if($pkg_id->num_rows == 0){
   $_SESSION['message'] = "Sorry, the package doesn't exist!";
        header("location: ../../Business_Logins/error.php");
}?>
<html>
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <link rel="stylesheet" type="text/css" href="css/style.css">
    <title><?php echo $pkg["package_name"] ?></title>
    <!-- Anno CDN -->
    <style>
        div.info {
    color: white;
    text-align: center;
    padding: 1px;
    margin-top: -20px;
    margin-bottom: 15px;
/* Special keyword values */
    background-color: transparent;

}
    </style>
     <!--Anno CDN-->
</head>

<body class="container" style="background: #7b4397;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #dc2430, #7b4397);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #dc2430, #7b4397); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
; font-family: Quicksand"><h4 class="white-text">CHECKOUT FORM <img src="coins.gif"></h4> <br>
<?php
           if ($_SERVER['REQUEST_METHOD'] == 'POST') 
          {
          if (isset($_POST['submit'])) { //user books
        if(!preg_match('/^[6-9][0-9]{9}$/', trim($mysqli->escape_string($_POST["number"])))) {
            
     echo 
              '<div class="info">
              Only Valid Mobile Numbers are allowed !
              </div>';
                } 
            elseif(!filter_var($mysqli->escape_string($_POST["email"]), FILTER_VALIDATE_EMAIL)) {
                echo 
              '<div class="info">
              Only Valid E-mail Id is accepted !
              </div>';
            }
             
             elseif(($mysqli->escape_string($_POST["pay"]))!=$pkg["package_fee"]) {
                echo 
              '<div class="info">
              Amount Mismatch!
              </div>';
            }
            elseif(($mysqli->escape_string($_POST["tour_operator"]))!=$t["name"]) {
                echo 
              '<div class="info">
              Name <ismatch!
              </div>';
            }
            elseif(($mysqli->escape_string($_POST["package"]))!=$pkg["package_name"]) {
                echo 
              '<div class="info">
              Name Mismatch!
              </div>';
            }
        else {require 'payment.php';}
        
            }
          }
           ?>
      <form class="col s12" id="book" action="" method="post">
    <input type="hidden" name="pkg_id" value="<?php echo $package_id; ?>">
    <input type="hidden" name="tour_id" value="<?php echo $id; ?>">
      <div class="row">
        <div class="input-field col s12 m6">
          <input placeholder="Placeholder" id="tour_operator" name="tour_operator" type="text" class="white-text" readonly value="<?php echo $t["name"]; ?>" >
          <label for="first_name"></label>
        </div>
        <div class="input-field col s12 m6">
          <input placeholder="Placeholder" id="package" type="text" name="package" class="white-text" readonly value="<?php echo $pkg["package_name"]; ?>">
          <label for="first_name">Package Name</label>
        </div>
    </div>
    <div class="row">
        <div class="input-field col s12 m4">
            <input placeholder="How many tourists?" id="person" name="person" type="number" class="validate" min="1" max="10">
          <label for="person">No. of person</label>
        </div>
        <div class="input-field col s12 m5 push-m2">
            <input placeholder="Placeholder" id="pay" name="pay" type="number" readonly class="white-text"  value= "<?php echo $pkg["package_fee"]; ?>">
          <label for="pay">Package amount per person in INR</label>
        </div>
        <div class="row">
            <div class="input-field col s12 m4">
          <input id="name" type="text" name="name" required class="validate">
          <label for="name">Enter Your Name</label>
        </div>
            <div class="input-field col s12 m4">
        <input id="email" name="email" type="email" required class="validate">
            <label for="email">Provide your e-mail</label>
            <span class="helper-text" data-error="Email format not correct" data-success="Accepted"></span>
            </div>
            <div class="input-field col s12 m4">
        <input id="number" name="number" type="number" required class="validate">
            <label for="number">Provide your Contact</label>
            <span class="helper-text" data-error="Contact format not correct" data-success="Accepted"></span>
            </div>
            </div>
            
            <button class="btn waves-effect waves-light indigo" type="submit" name="submit" value="submit">PAY NOW
    <i class="material-icons right">send</i>
  </button>
    </div>
    </form>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/js/materialize.min.js"></script>
    
    <script>
        const sideNav=document.querySelector('.sidenav');
         M.Sidenav.init(sideNav,{});
        $('.dropdown-trigger1').dropdown();
        $('.dropdown-trigger2').dropdown();
        $('.dropdown-trigger3').dropdown();
        $('.dropdown-trigger4').dropdown();
        $('.dropdown-trigger5').dropdown();
        $('.dropdown-trigger6').dropdown();
       $('.modal').modal();
       $('.tooltipped').tooltip();
         $('.collapsible').collapsible();
       $('.fixed-action-btn').floatingActionButton({
            direction: 'left'
  });
    </body>
    </html>