<?php
require 'db.php';
session_start();
// Check if user is logged in using the session variable
if ( !isset($_SESSION['logged_in'])) {
    //If the user is not logged in then check the url for unique email
    if((isset($_GET['id'])) && (isset($_GET['package_id']))) {
        $id = $_GET['id'];
        $package_id = $_GET['package_id'];
    } else {
        //If the user is not logged in and also the url doesn't contain unique email then we can't render the company page.
        $_SESSION['message'] = "Sorry, the company page doesn't exist!";
        header("location: ../../Business_Logins/error.php");
    }    
}
else if ( isset($_SESSION['logged_in'])) {
    //If the user is not logged in then check the url for unique email
    if((isset($_GET['id'])) && (isset($_GET['package_id']))) {
        $id = $_GET['id'];
        $package_id = $_GET['package_id'];
    } 
    else {
      $first_name = $_SESSION['first_name'];
    $last_name = $_SESSION['last_name'];
    $email = $_SESSION['email'];
    $active = $_SESSION['active'];
    $id=$_SESSION['id'];
    }
}
$pkg_id=$mysqli->query("SELECT * FROM tour_packages WHERE package_id = '$package_id'");
$t_id = $mysqli->query("SELECT * FROM tour_operators WHERE id = '$id'");
$pkg = $pkg_id->fetch_assoc();
$t = $t_id->fetch_assoc();
//$info=mysqli_query($mysqli,$sql);
if($pkg_id->num_rows == 0){
   $_SESSION['message'] = "Sorry, the package doesn't exist!";
        header("location: ../../Business_Logins/error.php");
}?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <link rel="stylesheet" type="text/css" href="css/style.css">
    <title><?php echo $pkg["package_name"] ?></title>
    <!-- Anno CDN -->
    <style>
        div.info {
    color: pink;
    display: box;
    text-align: center;
    padding: 5px;
    margin-top: -20px;
    margin-bottom: 15px;
    border: 1px solid red;
    background: #66131c;
}
    </style>
     <!--Anno CDN-->
</head>
<body class="grey lighten-2">
 <nav class="white">
    <div class="nav-wrapper">
       <a href="" style="font-size:1.5em;" class="brand-logo center red-text "><i class="material-icons red-text">person_pin</i><?php echo $pkg["package_name"]; ?></a>
       </div>
    </div>
  </nav>
 
  <section>
       <div class="row">
           <div class="col s12 m8">
              <div class="card-panel" style="background: linear-gradient(to right, #DAE2F8 , #D6A4A4);">
               <div class="row">
                  <div class="col s12 m12">
                     <!--****Slider****-->
                       <div class="slider">
                           <ul class="slides">
                             <li>
                                <img src="img/m.jpg" class="responsive-img"> <!-- random image -->                       
                             </li>
                             <li>
                                 <img src="img/s.jpg" class="responsive-img"> <!-- random image -->  
                             </li>
                             <li>
                                 <img src="img/w.jpg" class="responsive-img"> <!-- random image -->
                             </li>
                             
                         </ul>
                       </div>
                     <!--****slider End****-->
                  </div>
                  <h4 class="black-text" style="font-family: Pacifico;"><strong><?php echo $pkg["package_name"];?></strong></h4>
                  <h4 class="" style="text-transform: uppercase;
	background: linear-gradient(to right, #b92b27 0%, #1565C0 100%);
	-webkit-background-clip: text;
	-webkit-text-fill-color: transparent;"><?php echo $pkg["dates"];?></h4>
                  <div class="row">
                        <div class="container">
                        <div class="col s12 m12" >
                          <h6><i class="fas fa-map-marker-alt white-text">Company Located at: </i><?php echo $t["location"]; ?></h6> 
                          <h6 class="black-text"><i class="tiny material-icons blue-text">business</i>Travel and Tour Services</h6>
                     	   <h6 class="black-text">Travelling from <?php echo $t["city"]; ?><i class="tiny material-icons">chevron_right</i><?php echo $pkg["package_city"]; ?></h6>
                     	    <h6 class="black-text">Suggested Places to visit:<?php 
                     	    $a=explode(',', $pkg["package_places"]);
                     	    $i=0; 
                     	    for($j=0;$j<count($a);$j++){?>
                     	         <div class="chip yellow blue-text"><?php echo $a[$i];?>
                                    </div>
                     	   <?php $i++;}
                     	    ?><h6>
                     	    <h6 class="black-text"><strong>Services provided:</strong>
                     	       <?php $b=explode('|', $t["services"]);
                     	    $i=0; 
                     	    for($j=0;$j<count($b);$j++){?>
                     	         <div class="chip indigo white-text"><?php echo $b[$i];?>
                                    </div>
                     	   <?php $i++;}
                     	    ?>
                     	    </h6>
                     	    
                        </div> 
                        </div>
                      </div>
                  </div>
               </div>
   <section>
      <!--Cars--> 
           <div class="row">
               <div class="col s12 m12 white z-depth-2" style="background: linear-gradient(to right, #DAE2F8 , #D6A4A4);">
                  <h5 class="center indigo white-text card" style="background: linear-gradient(to right, #42275a , #743b68);">PACKAGE SPECIFICATIONS</h5>
                   <div class="row">
                       <div class="col s12 m12" >
                           <h5 class="black-text" style="font-family: Quicksand;"><?php echo $pkg["package_details"];?></h5>
                      </div>
                      
                     
                   </div>
               </div>
           </div>
      <!--Cars end-->  
</section>  
<section>
      <!--Drivers details--> 
           <div class="row">
               <div class="col s12 m12 white z-depth-2" style="background: linear-gradient(to right, #DAE2F8 , #D6A4A4);">
                  <h5 class="center indigo white-text card" style="background: linear-gradient(to right, #42275a , #743b68);">PACKAGE INITENERARY</h5>
                   <div class="row">
                       <div class="col s12 m12" >
                           <h5 class="black-text"style="font-family: Quicksand;"><?php echo $pkg["package_itinerary"];?></h5>
                      </div>
                      
                     
                   </div>
               </div>
           </div>
      <!--drivers details end-->  
      
    
      <div class="col s12">
      <a class="indigo-text"href="https://www.tourlancers.com/beta/business/Operators/Operator_company_page_build/user.php?id=<?php echo $t["id"]; ?>" >View Company page</a>
        </div>
  </section>  
</div>
      
         <div class="col s12 m4">
            <div class="card-panel" style="background: linear-gradient(to right, #D6A4A4 , #ff6e7f);">
                <h5 class="center  white-text card" style="background: linear-gradient(to right, #42275a , #743b68);">BOOKINGS</a></h5>
             <div class="row">
                 <div class="col s6 m7">
                     <h5><span class="white-text">&#8377;</span><strike> <?php $f=$pkg["package_fee"]; 
                     $dis=.65*$f+$f;
                     echo $dis;?>/-</strike></h5>Discount will end soon!
                    
                    <p style="color:blue">Now at:</p> <h5> <span class="white-text">&#8377;</span> <?php echo $pkg["package_fee"]; ?>/- only <a class="tooltipped" data-position="bottom" data-tooltip="<?php echo $pkg["Inclusions"]; ?>"><i class="material-icons" style="color: grey">info</i></h5>
                    <p style="color:white"> *coupon codes/discounts applied. Hurry! Offers ends on 28th October,2018 </p>
                    </div>
                    <div class="col s12 m5">
                    <ul class="collapsible z-depth-0">
                    <li>
      <div class="collapsible-header "><i class="material-icons">info</i>POLICIES</div>
      <div class="collapsible-body white-text"><span>Pay &#8377; <?php echo $pkg["package_fee"]; ?> for this package/person. The total number of tourists added will multiply the cost in our systems<br> This is inclusive of all taxes and discounts. This money can be refunded within a span of 45 days.</span></div>
                </li>
                 </div>
                  <div class="row">
                 <div class="col s12">
                      <a class="waves-effect waves-light  white-text btn-large modal-trigger" style="background: linear-gradient(to right, #c31432 , #240b36);" href="book.php?id=<?php echo $t['id'];?>&package_id=<?php echo $pkg['package_id']; ?>">Book Now</a></div></div>
                
             </div>
             <h6><i class="fa fa-cc-discover " style="font-size:36px;color:gray"></i>
             <i class="fa fa-cc-mastercard" style="font-size:36px;color:indigo"></i>
             <i class="fa fa-cc-visa" style="font-size:36px;color:indigo"></i>
             <i class="fa fa-credit-card" style="font-size:36px;color:indigo"></i></h6>
           </div>
           
           <!-- Exclusion -->
           <div class="card-panel" style="background: linear-gradient(to right, #D6A4A4 , #ff6e7f);">
                <h5 class="center  white-text card" style="background: linear-gradient(to right, #42275a , #743b68);">EXCLUSIONS</a></h5>
                   <h6><?php echo $pkg["Exclusions"];?></h6>
                </div>
           <div class="card-panel" style="background: linear-gradient(to right, #D6A4A4 , #ff6e7f);">
                <h5 class="center  white-text card" style="background: linear-gradient(to right, #42275a , #743b68);">SPECIAL SERVICES</a></h5>
                 
                    
                      <?php 
                      $arr=explode(',', $pkg["special_service"]);
                      $i=0; for($j=0;$j<count($arr);$j++){ ?>
                      <li><?php echo $arr[$i]; ?></li>
                      <?php
                      $i++;
                            }
                      
                       ?>
                </div>
                
           <p style="color:blue">Ads</p>
            <div class="card-panel">
             <div class="row">
                 
                 <div class="col s12">
                    <img src="img/banner.jpeg" class="responsive-img">
                 </div>
             </div>
           </div>
         </div>
         <div class="fixed-action-btn">
  <a class="btn-floating btn-large green">
    <i class="large material-icons">info</i> 
  </a>
  <ul>
  
    <li><a class="btn-floating red" href="https://www.google.co.in/maps/"><i class="material-icons">location_on</i></a></li>
    
  </ul>
</div>
       </div>
      
    </div></div>
             
 </section>
      <!--Social Media follow-->
      
          <!--Social Media follow End-->
          <!--footer-->
     
    
      
    </div>
       <!--footer end-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/js/materialize.min.js"></script>
    
    <script>
        const sideNav=document.querySelector('.sidenav');
         M.Sidenav.init(sideNav,{});
        $('.dropdown-trigger1').dropdown();
        $('.dropdown-trigger2').dropdown();
        $('.dropdown-trigger3').dropdown();
        $('.dropdown-trigger4').dropdown();
        $('.dropdown-trigger5').dropdown();
        $('.dropdown-trigger6').dropdown();
       $('.modal').modal();
       $('.tooltipped').tooltip();
         $('.collapsible').collapsible();
       $('.fixed-action-btn').floatingActionButton({
            direction: 'left'
  });


//slider
const slider=document.querySelector('.slider');
M.Slider.init(slider,{
      indicators:false,
      height:400,
      transition:500,
      interval:2000});
const mb=document.querySelectorAll('.materialboxed');
M.Materialbox.init(mb,{});
    </script>
    <script language="javascript">document.onmousedown=disableclick;status="Right Click Disabled";function disableclick(event){  if(event.button==2)   {     alert(status);     return false;       }}</script>
</body>
</html>