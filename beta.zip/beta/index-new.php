
<!DOCTYPE html>
<html>
  <head>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/css?family=Cabin" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">

    <script src="https://www.gstatic.com/firebasejs/5.0.4/firebase.js"></script>
    <script>
    var config = {
      apiKey: "AIzaSyB6M9ZFNHcZ0zGl5n9Fl4veyjeH8NL7ChU",
      authDomain: "tourlancers-logins.firebaseapp.com",
      databaseURL: "https://tourlancers-logins.firebaseio.com",
      projectId: "tourlancers-logins",
      storageBucket: "tourlancers-logins.appspot.com",
      messagingSenderId: "213279812943"
    };
    firebase.initializeApp(config);
    var user = firebase.auth().currentUser;
    var name, email;
    firebase.auth().onAuthStateChanged(function(user) {
if (user) {
  // User is signed in.
  document.getElementById("googleemail").innerHTML=user.email;
  document.getElementById("googleemail1").innerHTML=user.email;
  document.getElementById("userdrop").style.display="visible";
  document.getElementById("userdrop1").style.display="visible";
  document.getElementById("username").innerHTML= user.displayName;
  document.getElementById("username1").innerHTML= user.displayName;
 // document.getElementById("userdrop").style.display="visible";
 document.getElementsByTagName("i")[0].removeAttribute("onclick");

} else {
  document.getElementById("username").innerHTML="sign in";
  document.getElementById("username1").innerHTML="sign in";
  document.getElementById("userdrop").style.display="none";
  document.getElementById("userdrop1").style.display="none";
  document.getElementById("dropdown10").style.visibility="hidden";
  document.getElementById("dropdown11").style.visibility="hidden";
 //document.getElementsByTagName("a")[0].removeAttribute("data-target");
}
});

function google(){
  var provider = new firebase.auth.GoogleAuthProvider();
firebase.auth().signInWithPopup(provider).then(function(result) {
  // This gives you a Google Access Token. You can use it to access the Google API.
  var token = result.credential.accessToken;
  // The signed-in user info.
  var user = result.user;
  console.log(user.displayName);
  console.log(user.email);
  // ...
}).catch(function(error) {
  // Handle Errors here.
  var errorCode = error.code;
  var errorMessage = error.message;
  console.log(errorCode);
  console.log(errorMessage)
  // The email of the user's account used.
  var email = error.email;
  // The firebase.auth.AuthCredential type that was used.
  var credential = error.credential;
  // ...
});

// Step 1.
// User tries to sign in to Google.
auth.signInWithPopup(new firebase.auth.GoogleAuthProvider()).catch(function(error) {
  // An error happened.
  if (error.code === 'auth/account-exists-with-different-credential') {
    // Step 2.
    // User's email already exists.
    // The pending Google credential.
    var pendingCred = error.credential;
    // The provider account's email address.
    var email = error.email;
    // Get sign-in methods for this email.
    auth.fetchSignInMethodsForEmail(email).then(function(methods) {
      // Step 3.
      // If the user has several sign-in methods,
      // the first method in the list will be the "recommended" method to use.
      if (methods[0] === 'password') {
        // Asks the user his password.
        // In real scenario, you should handle this asynchronously.
        var password = promptUserForPassword(); // TODO: implement promptUserForPassword.
        auth.signInWithEmailAndPassword(email, password).then(function(user) {
          // Step 4a.
          return user.link(pendingCred);
        }).then(function() {
          // Google account successfully linked to the existing Firebase user.
          goToApp();
        });
        return;
      }

      // TODO: implement getProviderForProviderId.
      var provider = getProviderForProviderId(methods[0]);
      auth.signInWithPopup(provider).then(function(result) {
        result.user.linkAndRetrieveDataWithCredential(pendingCred).then(function(usercred) {
          // Google account successfully linked to the existing Firebase user.
          goToApp();
        });
      });
    });
  }
});

}

//--------------------------------
//logout
function logout()
{
  firebase.auth().signOut().then(function() {
  // Sign-out successful.
}).catch(function(error) {
  console.log("Not Logged out");
});
}

//user details
var user = firebase.auth().currentUser;
var name, email;

/* if (user != null) {
  //name = user.displayName;
  email = user.email;
  document.getElementById("googleemail").innerHTML=email;
  document.getElementById("googleuser").style.visibility = "visible";
  document.getElementById("userdrop").style.visibility = "visible";
}
*/


    </script>
    <!--<script>
        function startTime() {
            var today = new Date();
            var h = today.getHours();
            var m = today.getMinutes();
            var s = today.getSeconds();
            m = checkTime(m);
            s = checkTime(s);
            date = new Date;
           year = date.getFullYear();
           month = date.getMonth();
           months = new Array('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec');
           d = date.getDate();
           day = date.getDay();
           days = new Array('Sun', 'Mon', 'Tues', 'Wed', 'Thu', 'Fri', 'Sat');
            document.getElementById('show_time').innerHTML = ''+days[day]+', '+d+' '+months[month]+' '+ h + ":" + m + ":" + s +' IST  ';
            var t = setTimeout(startTime, 500);
        }
        function checkTime(i) {
            if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
            return i;
        }
        </script>
      -->
        <!-- page Loader -->
         <script language="javascript">
		
		
        $('document').ready(function(e) {
        
             $(".loader").fadeOut("slow"); 
            }); 
       
    </script> 
     <style>
	   .loader{ position: fixed;left: 0px;top: 0px;width:100%;height:100%;z-index: 9999;background: url(loader.gif) 50% 50% no-repeat rgb(249,249,249);}         
	   
	   </style>
    <!--page loader-->    

  </head>
      <title>Tourlancers</title>
  <body>
  <div class="loader"></div>  
    <!--Nav bar start-->
    <div class="navbar-fixed">

        <nav class="red darken-2">
             
            <div class="container">
                <div class="nav-wrapper">
                    <a href="#" class="brand-logo logo ">Tourlancers</a>
                    <a href="#" class="right hide-on-small-only" id="show_time"></a>
                    <a href="" data-target="mobile-nav" class="sidenav-trigger  pulse red darken-2">
                        <i class="material-icons ">menu</i>
                    </a>
                    <ul class="right hide-on-med-and-down">

                         <li>
                            <a class='dropdown-trigger1' href='#' data-target='dropdown1'><i class="fa fa-shopping-cart"></i> <span class="white-text"> Deals </span> <i class="material-icons right">arrow_drop_down</i></a>


                            <ul id='dropdown1' class='dropdown-content'>

                              <li><a href="#!"><i class="fa fa-store"></i>Rooms</a></li>
                              <li class="divider" tabindex="-1"></li>
                              <li><a href="#!"><i class="fa fa-car"></i>Car Services</a></li>
                              <li class="divider" tabindex="-1"></li>
                              <li><a href="#!"><i class="fa fa-user-circle"></i>Guides</a></li>
                              <li class="divider" tabindex="-1"></li>
                          </ul>
                        </li>



                        <li>
                            <a href="business/Business_Logins/"><i class="fa fa-suitcase"></i> <span class="white-text"> TL for Business </span></a>
                        </li>
                         
                         <li>
                             <!-- Dropdown Trigger -->
                             <a class='dropdown-trigger10' href='#' data-target='dropdown10'><i class="fab fa-google" onclick="google()"></i> <span class="white-text" id="username"></span>
                                <i class="material-icons right" id="userdrop" >arrow_drop_down</i></a>

                             <!-- Dropdown Structure -->
                             <ul id='dropdown10' class='dropdown-content' width="30">
                                <li><a href="#!" id="googleemail"></a></li>
                                <li><a href="#!" onclick="logout()">Logout</a></li>
                                
                              </ul> 
                         </li>
                       

                    </ul>
                </div>
            </div>
        </nav>
    </div>
    <ul class="sidenav red darken-2" id="mobile-nav">
        <li>
            <a href="index.php"><i class="fa fa-home"></i><span class="white-text"> Home </span></a>
        </li>
        <li>
            <a class='dropdown-trigger3' href='#' data-target='dropdown3'><i class="fa fa-shopping-cart"></i> <span class="white-text"> Deals</span><i class="material-icons right">arrow_drop_down</i></a>

            <!-- Dropdown Structure -->
            <ul id='dropdown3' class='dropdown-content'>
              <li><a href="#!"><i class="fa fa-room"></i>Rooms</a></li>
              <li class="divider" tabindex="-1"></li>
              <li><a href="#!"><i class="fa fa-store"></i>Operators</a></li>
              <li class="divider" tabindex="-1"></li>
              <li><a href="#!"><i class="fa fa-car"></i>Car Services</a></li>
              <li class="divider" tabindex="-1"></li>
              


            </ul>
        </li>



        <li>
                <a href="business/Business_Logins/"><i class="fa fa-suitcase"></i><span class="white-text"> TL for Business </span></a>
        </li>
         

        <li>
                 <!-- Dropdown Trigger -->
                 <a class='dropdown-trigger11' href='#' data-target='dropdown11'><i class="fab fa-google"  onclick="google()"></i> <span class="white-text" id="username1"></span>
                    <i class="material-icons right" id="userdrop1" >arrow_drop_down</i></a>

                 <!-- Dropdown Structure -->
                 <ul id='dropdown11' class='dropdown-content'>
                    <li><a href="#!" id="googleemail1"></a></li>
                    <li><a href="#!" onclick="logout()">Logout</a></li>
                    
                  </ul> 
        </li>
        </ul>
    <!--Nav bar End-->

    <!--Start of Sliders-->
    <section class="slider">

        <ul class="slides">
          <li>
            <img src="img/sunglass.jpeg">
            <div class="caption center-align">
              <h3 >Take your Dream Vacation!</h3>
              <h5 class="light grey-text text-lighten-3">Live your life. Take the best services from Tourlancers to enjoy every moment.</h5>
            </div>
          </li>
          <li>
            <img src="img/mountain-min.JPG">
            <div class="caption left-align">
              <h3 class="light black-text text-lighten-3">Join the Tourlancers Community</h3>
              <h5 class="light white-text text-lighten-3">Help us grow and build Tourism in India.</h5>
            </div>
          </li>
          <li>
            <img src="img/car1.jpeg" >
            <div class="caption right-align">
              <h3 class="light black-text text-lighten-3">Explore India like never before</h3>
              <h5 class="light black-text text-lighten-3">Get the best Car services, tour services from us. Make your journey a rememberable one.</h5>
            </div>
          </li>

           <section id="search" class="section section-search teal darken-1 white-text center scrollspy">

           </section>
        </ul>
   </section>

    <!--End of Sliders-->
    <!--Search Area-->
    <nav class="hide-on-med-and-down">
        <div class="nav-wrapper red darken-2">
          <div class="container1">
            <ul id="nav-mobile" class="left"> 
               <?php     
                  $city=array("PURI","ANDAMAN AND NICOBAR","GOA","ASSAM","CHENNAI","BANGALORE","HYDERABAD","KOLKATA","DELHI","UTTARAKHAND");
                  
                  for($i=0;$i<count($city);$i++)
                  {
                    echo "<li><a  href='catagory/index.php?city=".strtolower($city[$i])."'>".$city[$i]."</a></li>" ; 
                  }
                ?>

              </ul>
          </div>
        </div>
      </nav>
     <!--Medium screen nav-->
      <nav class="hide-on-large-only hide-on-small-only">
        <div class="nav-wrapper red darken-2">
          <div class="center-align container">
            <ul id="nav-mobile" class="left">
                <li><a href=""><i class="fa fa-map-marker-alt"></i></a></li>
                <li><a class='dropdown-trigger6' href='' data-target='dropdown6'>OUR CITIES <i class="material-icons right">arrow_drop_down</i></a>

                   <!-- Dropdown Structure -->
                   <ul id='dropdown6' class='dropdown-content'>
                      <?php     
                        $city=array("PURI","ANDAMAN AND NICOBAR","GOA","ASSAM","CHENNAI","BANGALORE","HYDERABAD","KOLKATA","DELHI","UTTARAKHAND");
                  
                          for($i=0;$i<count($city);$i++)
                            {
                              echo "<li class='divider' tabindex='-1'></li>";  
                              echo "<li><a  href='catagory/index.php?city=".strtolower($city[$i])."'>".$city[$i]."</a></li>" ;
                              echo "<li class='divider' tabindex='-1'></li>"; 
                            }
                       ?>  
                  </ul>
                </li>
               

              </ul>
          </div>
        </div>
      </nav>
      <!--Medium screen nav end-->
      <!--for mobile screen only-->
        <nav class="hide-on-med-and-up small-nav">
            <div class="nav-wrapper red darken-2">
                 <div class="container">
                    <div class="row">
                       <div class="col s12 right-align">
                          <ul  class="left">

                               <li><a class='dropdown-trigger8' href='' data-target='dropdown8'><i class="fa fa-map-marker-alt"></i> OUR CITIES <i class="material-icons right">arrow_drop_down</i></a>

                                      <!-- Dropdown Structure -->
                                  <ul id='dropdown8' class='dropdown-content'>
                                     <?php     
                                         $city=array("PURI","ANDAMAN","GOA","ASSAM","CHENNAI","BANGALORE","HYDERABAD","KOLKATA","DELHI");
                  
                                         for($i=0;$i<count($city);$i++)
                                           {
                                            echo "<li class='divider' tabindex='-1'></li>";  
                                            echo "<li><a  href='catagory/index.php?city=".strtolower($city[$i])."'>".$city[$i]."</a></li>" ;
                                            echo "<li class='divider' tabindex='-1'></li>"; 
                                           }
                                      ?>  
                                </ul>
                             </li>
                          </ul>
                       </div>
                      
                    </ul>
                      </div>
                   </div>
                 </div>
            </div>
        </nav>
     <!--for mobile screen only-End-->
    <!--Search Area End-->
    <!--Section icon boxes-->
    <section class="section section-icons  blue-grey lighten-4 center">
            <div class="container">
                <div class="row">
                    <h4 class="center"><span class="red-text">Our</span> Deals</h4>
                    <a href="#">
                    <div class="col s12 m4">
                        <div class="card-panel"><i class="material-icons large teal-text">room</i>
                        <h4><a style="color:black;"  href="">Pick Room </a></h4>
                        <p> Book Hotels and have a comfortable stay at them. Get hassle-free stays at the best hotels of India
                       </p>
                        </div>
                    </div>
                    </a>
                    <a href="#">
                    <div class="col s12 m4">
                        <div class="card-panel"><i class="material-icons large teal-text">store</i>
                            <h4><a style="color:black;" href="">Travel Operators </a></h4>
                            <p>They will guide you throughout the entire journey and complete your tour like professionals</p>
                        </div>
                    </div>
                    </a>
                  <a href="#">
                      <div class="col s12 m4">
                         <div class="card-panel"><i class="material-icons large teal-text">person</i>
                            <h4><a style="color:black;" href="">Tour guides</a></h4>
                            <p>Book Local Tour guides. Get connected to them and make your trips exciting. </p>
                         </div>
                    </div>
                 </a>
                </div>
                 <!--Video-->
                  <div class="row">
                    <div class="col s12 m6">
                     <div class="video-container">
                        <iframe width="540" height="370" src="https://biteable.com/watch/embed/tourlancers-1766681" frameborder="0" allowfullscreen></iframe>
                     </div>
                   </div>
                 <div class="col s12 m6">
                    <h5> Summer is at Tourlancers </h5>

                      <p style="padding-left:10%;text-align:justify;">A tangerine sunset. A shimmering pool. A kiss to the clouds. Choose from a range of stays with Tourlancers - Hotels, Homes, Houseboats, Treehouses, Apartments, Resorts, Villas, Townhouses. #SummerIsAtTourlancers at 50% off! </p>
                      <a href="#" class="waves-effect waves-light btn btn-large red pulse">BOOK NOW!</a>
                 </div>
                </div>
               <!--Video End -->
            </div>
        </section>
        <!--icon boxes end -->



         <!--popular places Start-->
     <section id="popular" class="section grey darken-4 section-popular scrollspy">
            <div class="container">
                <div class="row">
                    <h4 class="center"><span class="teal-text">Popular Places</span></h4>
                    <a href="catagory/index.php?city=shimla">
                      <div class="col s12 m4">
                        <div class="card">
                            <div class="card-image">
                                <img src="img/hill-station-1576868_640.jpg" alt="london">
                                <span class="card-title">Hill Station</span>

                            </div>
                            <div class="card-content">
                               <b>Come and enjoy the beautiful day of Hill Station </b>
                            </div>
                        </div>
                    </div>
                    </a>
                    <a href="catagory/index.php?city=shimla">
                    <div class="col s12 m4">
                      <div class="card">
                          <div class="card-image">
                              <img  src="img/shimla-555897_640.jpg" alt="Shimla">
                              <span style="color:bisque" class="card-title">Shimla</span>
                          </div>
                          <div class="card-content">
                             <b>Let's have a fun on the snow layers of Shimla </b>
                          </div>
                      </div>
                  </div>
                  </a>
                  <a href="catagory/index.php?city=thiland">
                  <div class="col s12 m4">
                      <div class="card">
                          <div class="card-image">
                              <img src="img/bedroom-1285156_640.jpg" alt="gantok">
                              <span class="card-title">Beautiful Bedroom</span>
                          </div>
                          <div class="card-content">
                            <b> A beautiful day starts with a beautiful morning ,Thiland </b>
                          </div>
                      </div>
                  </div>
                </div>
                </a>
                <div class="row">
                    <a href="catagory/index.php?city=puri">
                      <div class="col s12 m4">
                          <div class="card">
                              <div class="card-image">
                                  <img src="img/houses.jpg" alt="london">
                                  <span class="card-title">Beautiful Evening</span>

                              </div>
                              <div class="card-content">
                                 <b>Come and enjoy the beautiful day of Hill Station </b>
                              </div>
                          </div>
                      </div>
                      </a>
                      <a href="catagory/index.php?city=gangtok">
                      <div class="col s12 m4">
                        <div class="card">
                            <div class="card-image">
                                <img  src="img/waterfall-1369319_640.jpg" alt="Shimla">
                                <span style="color:bisque" class="card-title">Gangtok,Waterfall</span>
                            </div>
                            <div class="card-content">
                               <b>Let's have a fun on the waterfall of Gangtok </b>
                            </div>
                        </div>
                    </div>
                    </a>
                    <a href="catagory/index.php?city=himalaya">
                    <div class="col s12 m4">
                        <div class="card">
                            <div class="card-image">
                                <img src="img/mountains-2915425_640.jpg" alt="gantok">
                                <span class="card-title">Dark Evening,Himalaya mountain</span>
                            </div>
                            <div class="card-content">
                              <b> A beautiful day starts with a beautiful dark evening ,Himalaya </b>
                            </div>
                        </div>
                    </div>
                    </a>
                  </div>
            </div>

       </section>
      <!--popular places end-->

      <!--Social Media follow-->
      <footer class="section grey darken-1 white-text center" style="background: url('business/img/tourlancers.png') center no-repeat   ; 
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;">
     <section class="section section-follow  white-text center">
            <div class="container">
                <div class="row">
                    <div class="col s12">
                        <h4>Follow Tourlancers</h4>
                        <p>Follow us on social media for special offers</p>

                          <a href="https://www.linkedin.com/company/tourlancers" class="white-text">
                                  <i class="fab fa-linkedin fa-4x"></i>
                          </a>

                    </div>
                </div>
            </div>

           </section>

          <!--Social Media follow End-->
          <!--footer-->
      <section class="section  white-text center">
            <div class="container">
                <div class="row">
                    <div class="col s12 m4">
                      <h5>Information</h5>
                      <p>About us | Our products | Press Release</p>
                      <p>Customer Testimonial | Partner with Us </p>
                     </div>
                   <div class="col s12 m4">
                       <h5>Customer Care</h5>
                       <p>Support & FAQ | Term & Condition | Privacy Policy</p>
                       <p>User Agreement | Travel Agents</p>
                   </div>
                    <div class="col s12 m4">
                       <h5>Headquarters</h5>
                       <p>Kolkata, India</p>

                    </div>
                </div>
            </div>
        </section>


      <!--footer End-->
      <!--footer-->
    
            <p class="flow-text">Tourlancers &copy;2017-2018</p>
        </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/js/materialize.min.js"></script>
    <script>
     const sideNav=document.querySelector('.sidenav');
M.Sidenav.init(sideNav,{});
$('.dropdown-trigger1').dropdown();
$('.dropdown-trigger2').dropdown();
$('.dropdown-trigger3').dropdown();
$('.dropdown-trigger4').dropdown();
$('.dropdown-trigger5').dropdown();
$('.dropdown-trigger6').dropdown();
$('.dropdown-trigger7').dropdown();
$('.dropdown-trigger8').dropdown();
$('.dropdown-trigger9').dropdown();
$('.dropdown-trigger10').dropdown();
$('.dropdown-trigger11').dropdown();



//slider
const slider=document.querySelector('.slider');
M.Slider.init(slider,{
      indicators:false,
      height:400,
      transition:500,
      interval:3000});
const mb=document.querySelectorAll('.materialboxed');
M.Materialbox.init(mb,{});
    </script>
  </body>
</html>
